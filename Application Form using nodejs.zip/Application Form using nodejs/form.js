var express = require("express");
//var formidable = require("formidable");
var app = express();
app.use(express.static(__dirname + '/local'));
app.get("/ajax", (req, res) => {
    var name = req.query.name;
    var n_id = req.query.n_id;
    var email = req.query.email;
    var phone = req.query.phone;
    var gender = req.query.gender;
    var dob = req.query.dob;  
    var academy = req.query.academy;
    var data = { name: name, n_id: n_id, email: email, phone: phone, gender: gender, dob: dob, academy: academy, message: "Form submitted successfully." };

    //res.writeHead(200, { "Content-type": "application/json" })
    res.json(data);
});

app.listen(8080);
console.log("Server running at address: http://localhost:8080");