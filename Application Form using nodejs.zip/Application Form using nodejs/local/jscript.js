$(document).ready(() => {
    $("#send").click(() => {
        if (validateFormData() == true) {
            $.ajax({
                url: "/ajax",
                type: "get",
                dataType: "json",
                data: {
                    name: $("#name").val(),
                    n_id: $("#n_id").val(),
                    email: $("#email").val(),
                    phone: $("#phone").val(),
                    gender: $("#gender").val(),
                    dob: $("#dob").val(), 
                    academy: $("#academy").val()         
                },
                success: (result) => {
                    $("#output").html(`
                            Server Message: ${result.message}
                            <br />
                            Name: ${result.name} 
                            <br />
                            National ID: ${result.n_id}
                            <br />
                            Email: ${result.email}
                            <br />
                            Phone: ${result.phone}
                            <br />
                            Date of Birth: ${result.dob}
                            <br />
                            Gender: ${result.gender}
                            <br/>
                            Academic Qualifications: ${result.academy}`);
                    $("#output").show();
                }
            });
        }
    });
});

function validateFormData() {
    var isValid = true;
    var name = $("#name").val();
    var n_id = $("#n_id").val();
    var email = $("#email").val();
    var phone = $("#phone").val();
    var gender = $("#gender").val();
    var dob = $("#dob").val();
    var academy = $("#academy").val();

    if (name == null || name == "") {
        isValid = false;
        alert("Please Enter Name");
    } else if (n_id == null || n_id == "") {
        isValid = false;
        alert("Please Enter National Id");
    } else if (email == null || email == "") {
        isValid = false;
        alert("Please Enter Email");
    } else if (phone == null || phone == "") {
        isValid = false;
        alert("Please Enter Phone");
    }
    else if (gender == null || gender == "") {
        isValid = false;
        alert("Please Enter Gender");
    }
    else if (dob == null || dob == "") {
        isValid = false;
        alert("Please Enter Date of Birth");
    }  
    else if (academy == null || academy == "") {
        isValid = false;
        alert("Please Enter Academic Qualifications");
    }
    return isValid;
}